"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var name_1 = "Федька! Гляди кого поймал!";
console.log(name_1);
//# sourceMappingURL=index.js.map